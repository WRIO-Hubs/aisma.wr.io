function checkDMPage() {
  const currentURL = window.location.href;
  let attempts = 0;

  // Function to find the "Message" button and click it
  function findAndClickMessageButton() {
    const messageButton = document.querySelector('[data-testid="sendDMFromProfile"]');
    if (messageButton) {
      messageButton.click();
      // Replace "?dm" with "?dm_assist" in the URL after clicking the "Message" button
      if (currentURL.endsWith('?dm')) {
        const newURL = currentURL.replace('?dm', '?dm_assist');
        window.history.replaceState({}, document.title, newURL);
      }
    } else {
      attempts++;
      if (attempts < 10) {
        setTimeout(findAndClickMessageButton, 1000);
      }
    }
  }

  // Check if the URL ends with "?dm"
  if (currentURL.endsWith('?dm')) {
    findAndClickMessageButton();
  }
}

// Function to continuously check if the user is on the Twitter profile page with "?dm" in the URL
function handleURLChange() {
  let previousURL = window.location.href;

  setInterval(() => {
    const currentURL = window.location.href;
    if (currentURL !== previousURL) {
      checkDMPage();
      previousURL = currentURL;
    }
  }, 1000);
}

// Call the function to check if the user is on the Twitter profile page with "?dm" in the URL initially
checkDMPage();

// Call the function to start listening for URL changes
handleURLChange();
