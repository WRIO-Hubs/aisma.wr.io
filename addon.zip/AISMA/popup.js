document.addEventListener('DOMContentLoaded', function() {
  const openDashboardButton = document.getElementById('openDashboardButton');
  openDashboardButton.addEventListener('click', function() {
    chrome.tabs.create({ url: 'https://aisma.wr.io/dashboard/' });
  });
});

/*document.addEventListener('DOMContentLoaded', function() {
  chrome.storage.local.get(['profile_data', 'is_within_seven_days', 'direct_message', 'page_link'], function(result) {
    const profileData = result.profile_data;
    const isWithinSevenDays = result.is_within_seven_days;
    const directMessage = result.direct_message;
    const pageLink = result.page_link;

    if (profileData) {
      const profileDataElement = document.getElementById('profileData');
      profileDataElement.textContent = 'Profile Data: ' + profileData;
    }

    if (isWithinSevenDays !== undefined) {
      const withinSevenDaysElement = document.getElementById('withinSevenDays');
      withinSevenDaysElement.textContent = 'Within Seven Days: ' + (isWithinSevenDays ? 'Yes' : 'No');
    }

    if (directMessage !== undefined) {
      const directMessageElement = document.getElementById('directMessage');
      directMessageElement.textContent = 'Direct Message: ' + (directMessage ? 'Yes' : 'No');
    }

    if (pageLink) {
      const pageLinkElement = document.getElementById('pageLink');
      const link = document.createElement('a');
      link.setAttribute('href', pageLink);
      link.textContent = pageLink.replace('?scan', ''); // Remove the "?scan" parameter from the displayed link
      pageLinkElement.appendChild(link);
    }

  });
});*/
