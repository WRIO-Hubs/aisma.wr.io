let clickHandled = false; // Variable to track whether the click event has been handled
let tweetTextFound = false; // Variable to track whether the tweet text element is found
let tooltipElement; // Variable to store the tooltip element

let tweetComposeObserver;


// Function to check if the current URL matches the desired URL pattern
function isComposeTweetPage() {
  return window.location.href.includes('https://twitter.com/compose/tweet');
}

// Function to show true or false in the console based on the current URL
function checkURL() {
  const currentURL = isComposeTweetPage();
  console.log(currentURL);
  console.log('1');
  const helpTooltipElement = document.querySelector('#helpTooltip');
  if (helpTooltipElement) {
  console.log('2');
    if (currentURL) {
      console.log('2_1');
      helpTooltipElement.style.display = 'block'; // Show the tooltip
    } else {
      console.log('2_2');
      helpTooltipElement.style.display = 'none'; // Hide the tooltip
    }
  } else {

    console.log('3');
  }
}


// Function to start observing the DOM changes
function startMutationObserver() {
  tweetComposeObserver = new MutationObserver(() => {
    checkURL();
  });

  tweetComposeObserver.observe(document.documentElement, { childList: true, subtree: true });
}

// Function to stop observing the DOM changes
function stopMutationObserver() {
  if (tweetComposeObserver) {
    tweetComposeObserver.disconnect();
  }
}

// Function to handle the onpopstate event
function handlePopState() {
  checkURL();
  startMutationObserver();
}

// Add event listeners for onpopstate and DOMContentLoaded events
window.addEventListener('popstate', handlePopState);
document.addEventListener('DOMContentLoaded', handlePopState);

// Initial check when the script is first loaded
handlePopState();



function sendWebhook(text) {
  const webhookUrl = 'https://hook.eu1.make.com/ldxmj6ofmi1g3fhmep7w5eeemu8pk6om';
  fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text: text }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error('Webhook request failed');
      }
      return response.text(); // Parse the response body as text
    })
    .then((data) => {
      console.log('Webhook response:', data); // Log the response data
    })
    .catch((error) => {
      console.error('Failed to send webhook:', error);
    });
}

// Function to copy the text to the clipboard
function copyToClipboard(text) {
  // Create a temporary textarea to copy the text to the clipboard
  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.setAttribute('readonly', '');
  textarea.style.position = 'absolute';
  textarea.style.left = '-9999px';
  document.body.appendChild(textarea);

  // Copy the text from the textarea to the clipboard using the Clipboard API
  textarea.select();
  document.execCommand('copy');

  // Remove the temporary textarea
  document.body.removeChild(textarea);
}

// Function to handle the click event on the tweet compose page
function handleTweetComposeClick() {
  if (!clickHandled) {
    clickHandled = true; // Set clickHandled to true when the click event occurs
    checkURL();
    console.log(true); // Log 'true' to the console when the click event occurs
    if (tweetTextFound) {
      const tweetTextElement = document.querySelector('[data-testid="tweetText"] span');
      if (tweetTextElement) {
        const text = tweetTextElement.textContent;
        console.log('Scrapped Text:', text);
        sendWebhook(text);
      } else {
        console.log('Tweet text element not found.');
      }
    } else {
      console.log('Tweet text element not found.');
    }
  }
}

// Function to show the tooltip with Webhook response data
function showTooltip(data) {
  if (!tooltipElement) {
    // Fetch the tooltip CSS file and add the tooltip HTML to the body
    fetch(chrome.runtime.getURL('assets/css/tooltip.css'))
      .then((response) => response.text())
      .then((css) => {
        const styleElement = document.createElement('style');
        styleElement.innerHTML = css;
        document.head.appendChild(styleElement);
      })
      .then(() => {
        fetch(chrome.runtime.getURL('modules/tooltip-compose.html'))
          .then((response) => response.text())
          .then((html) => {
            const parser = new DOMParser();
            tooltipElement = parser.parseFromString(html, 'text/html').getElementById('helpTooltip');
          })
          .then(() => {
            document.body.appendChild(tooltipElement);
            showTooltipContent(data);

            checkURL();
          });
      });
  } else {
    showTooltipContent(data);
  }
}

// Function to create the "Copy to Clipboard" button and handle its click event
function createCopyButton(data) {
  const container = document.createElement('div');
  container.style.position = 'relative';

  const copyButton = document.createElement('button');
  copyButton.textContent = 'Copy to Clipboard';
  copyButton.id = 'copyToClipboardBtn';
  copyButton.style.marginTop = '10px';
  copyButton.style.padding = '5px 10px';
  copyButton.style.backgroundColor = '#4CAF50';
  copyButton.style.color = 'white';
  copyButton.style.border = 'none';
  copyButton.style.borderRadius = '4px';
  copyButton.style.cursor = 'pointer';

  copyButton.addEventListener('click', () => {
    copyToClipboard(data);
    console.log('Webhook response copied to clipboard successfully.');
  });

  container.appendChild(copyButton);

  return container;
}

// Function to handle the submit event when the user clicks the submit button
function handleWebhookSubmit() {
  const webhookPromptInput = document.getElementById('webhookPrompt');
  if (webhookPromptInput) {
    const prompt = webhookPromptInput.value;
    sendWebhook(prompt);
  }
}

// Function to show the tooltip content
function showTooltipContent(data) {

  const tooltipTextElement = tooltipElement ? tooltipElement.querySelector('.tooltip-text') : null;
  if (tooltipTextElement) {
    tooltipTextElement.textContent = data;
    tooltipElement.style.display = 'block';

    // Add the "Copy to Clipboard" button after the tooltip text
    const copyButtonContainer = createCopyButton(data);
    tooltipTextElement.appendChild(copyButtonContainer);

    // Add the form for custom prompt and submit button
    const formElement = document.createElement('div');
    formElement.className = 'tooltip-form';
    const promptInput = document.createElement('input');
    promptInput.type = 'text';
    promptInput.id = 'webhookPrompt';
    promptInput.placeholder = 'Enter prompt';
    formElement.appendChild(promptInput);
    const submitButton = document.createElement('button');
    submitButton.textContent = 'Submit';
    submitButton.id = 'submitWebhookBtn';
    submitButton.addEventListener('click', handleWebhookSubmit);
    formElement.appendChild(submitButton);
    tooltipTextElement.appendChild(formElement);
  } else {
    console.error('Tooltip text element not found.');
  }
}

// Function to hide the tooltip
/*function hideTooltip() {
  if (tooltipElement) {
    tooltipElement.style.display = 'none';
  }
}*/

// Function to find the "reply" button and attach the click event listener
function findReplyButton() {

  // Find the "reply" button
  const replyButton = document.querySelector('[data-testid="reply"]');

  if (replyButton && !tweetTextFound) {

    // Create and append the <span> element
    const spanElement = document.createElement('span');
    spanElement.innerHTML = 'AISMA<br><sup>powered</sup>';
    spanElement.style.position = 'absolute';
    spanElement.style.whiteSpace = 'nowrap';
    spanElement.style.right = '25px';
    spanElement.style.top = '15px';
    spanElement.style.fontWeight = 'bold';
    spanElement.style.fontFamily = 'sans-serif';
    spanElement.style.fontSize = 'small';
    spanElement.style.textAlign = 'center';
    spanElement.style.lineHeight = '10px';
    replyButton.appendChild(spanElement);

    // Set tweetTextFound to true when the "reply" button is found
    tweetTextFound = true;
    replyButton.addEventListener('click', handleTweetComposeClick);

    console.log('Element found! Click on "reply" button to scrape text.');

    // Show the tooltip when the "reply" button is found
    showTooltip('Tooltip content goes here.'); // Replace 'Tooltip content goes here.' with the actual data you want to display in the tooltip.

    // Stop observing the DOM changes once the reply button is found
    stopMutationObserver();
  }
}

// Add a 1-second delay before starting the MutationObserver
setTimeout(() => {
  // Use MutationObserver to wait for the "reply" button to be added to the DOM
  const observer = new MutationObserver(findReplyButton);
  observer.observe(document.documentElement, { childList: true, subtree: true });
}, 1000);
