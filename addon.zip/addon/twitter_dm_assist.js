function checkDMAssistPage() {
  const currentURL = window.location.href;
  let attempts = 0;

  // Function to find and add text to the element
  function findAndAddTextToElement() {
    const dmComposerTextInput = document.querySelector('[data-testid="dmComposerTextInput"]');
    if (dmComposerTextInput) {
        dmComposerTextInput.click();
        dmComposerTextInput.focus();
    } else {
      attempts++;
      if (attempts < 10) {
        setTimeout(findAndAddTextToElement, 1000);
      }
    }
  }

  // Check if the URL ends with "?dm_assist"
  if (currentURL.endsWith('?dm_assist')) {
    findAndAddTextToElement();
  }
}

// Function to continuously check if the URL has "?dm_assist"
function handleURLChange() {
  let previousURL = window.location.href;

  setInterval(() => {
    const currentURL = window.location.href;
    if (currentURL !== previousURL) {
      checkDMAssistPage();
      previousURL = currentURL;
    }
  }, 1000);
}

// Call the function to check if the URL has "?dm_assist" initially
checkDMAssistPage();

// Call the function to start listening for URL changes
handleURLChange();
